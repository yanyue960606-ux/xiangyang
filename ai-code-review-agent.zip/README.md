# AI Code Review Agent

基于大模型的自动代码评审与修复系统。

## 功能
- 自动分析 PR diff
- 检测 Bug / 性能 / 安全问题
- 自动生成修复建议
- 支持 CI 自动触发

## 使用方法
pip install -r requirements.txt
python review_agent.py

## 架构
- Review Agent：问题检测
- Fix Agent：自动修复
- CI 集成：自动触发评审
