import os
from openai import OpenAI

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

SYSTEM_PROMPT = """
你是一个资深代码评审工程师，请对以下代码变更进行审查：
重点关注：
1. 潜在 Bug
2. 性能问题
3. 安全风险
4. 代码规范

输出格式：
- 问题描述
- 风险等级（低/中/高）
- 修改建议
"""

def review_code(diff_text: str):
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": f"以下是PR的diff:\n{diff_text}"}
        ],
        temperature=0.3
    )
    return response.choices[0].message.content


def suggest_fix(diff_text: str):
    prompt = f"""
请根据以下代码变更，直接给出修改后的代码（只输出修复后的代码）：
{diff_text}
"""
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2
    )
    return response.choices[0].message.content


if __name__ == "__main__":
    with open("sample.diff", "r") as f:
        diff = f.read()

    print("🔍 代码审查结果：")
    print(review_code(diff))

    print("\n🛠 修复建议：")
    print(suggest_fix(diff))
